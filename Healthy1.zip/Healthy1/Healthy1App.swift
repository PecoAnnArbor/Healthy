//
//  HealthyApp.swift
//  Healthy
//
//  Created by Ian Zhang on 9/28/24.
//

import SwiftUI

@main
struct Healthy1App: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
